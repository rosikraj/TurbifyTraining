package com.infinite.Assessment7.repository;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinite.Assessment7.model.Municipal;
import com.infinite.Assessment7.model.MunicipalInfo;

@Repository
public class MunicipalDaoImpl implements ImunicipalDao {

	@Autowired
	private SessionFactory SessionFactory;

	public void setSfactory(SessionFactory sfactory) {
		this.SessionFactory = sfactory;
	}


	@Override
	public List<MunicipalInfo> getAllComplains() {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		List<MunicipalInfo> ls = session.createQuery("from MunicipalInfo").list();
		return ls;
	}

 

	@Override
	public MunicipalInfo getMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		MunicipalInfo municipalinfo = (MunicipalInfo) session.get(MunicipalInfo.class, id);
		return municipalinfo;
	}

 

	@Override
	public MunicipalInfo addMunicipal(MunicipalInfo municipalinfo) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		session.save(municipalinfo);
		return null;
	}

 

	@Override
	public void updateMunicipal(MunicipalInfo municipalinfo) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		Hibernate.initialize(municipalinfo);
		session.update(municipalinfo);		
	}

 

	@Override
	public void deleteMunicipal(int id) {
		// TODO Auto-generated method stub
		Session session = this.SessionFactory.getCurrentSession();
		MunicipalInfo m = (MunicipalInfo) session.load(MunicipalInfo.class, new Integer(id));
		if(null != m){
			session.delete(m);
		}
	}

	/*
	 * @Override public Municipal findByUsername(String UserName) { // TODO
	 * Auto-generated method stub return null; }
	 * 
	 * @Override public Municipal save(Municipal municipal) { Session session =
	 * this.sfactory.getCurrentSession(); session.save(municipal); return
	 * municipal; }
	 */

}
