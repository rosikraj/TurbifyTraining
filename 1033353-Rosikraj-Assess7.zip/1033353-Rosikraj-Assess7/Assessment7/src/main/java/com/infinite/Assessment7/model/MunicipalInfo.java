package com.infinite.Assessment7.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MunicipalInfo")
public class MunicipalInfo {
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

	@Column(name = "Name")
	private String name;

	@Column(name = "Date")
	private String date;

	@Column(name = "Address")
	private String address;

	@Column(name = "Modile")
	private String modile;

	@Column(name = "Email")
	private String email;

	@Column(name = "Complain")
	private String complain;

	@Column(name = "wardnum")
	private String wardnum;
	
	

	public MunicipalInfo() {
		//super();
	}

	public MunicipalInfo(String name, String date, String address, String modile, String email, String complain,
			String wardnum) {
		//super();
		this.name = name;
		this.date = date;
		this.address = address;
		this.modile = modile;
		this.email = email;
		this.complain = complain;
		this.wardnum = wardnum;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getModile() {
		return modile;
	}

	public void setModile(String modile) {
		this.modile = modile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getComplain() {
		return complain;
	}

	public void setComplain(String complain) {
		this.complain = complain;
	}

	public String getWardnum() {
		return wardnum;
	}

	public void setWardnum(String wardnum) {
		this.wardnum = wardnum;
	}

}
