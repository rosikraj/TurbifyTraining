package com.infinite.Assessment7.repository;

import java.util.List;

import com.infinite.Assessment7.model.Municipal;
import com.infinite.Assessment7.model.MunicipalInfo;

public interface ImunicipalDao {

	public List<MunicipalInfo> getAllComplains();

	public MunicipalInfo getMunicipal(int id);

	public MunicipalInfo addMunicipal(MunicipalInfo municipalinfo);

	public void updateMunicipal(MunicipalInfo municipalinfo);

	public void deleteMunicipal(int id);
	/*
	 * public Municipal findByUsername(String UserName); public Municipal
	 * save(Municipal municipal);
	 */ // public List<Municipal> getAllMunicipal();
		// public Municipal getMunicipal(int id);

	// public void login(Municipal municipal);

}
