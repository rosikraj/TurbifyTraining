package com.infinite.daoimpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.infinite.daohelper.DaoHelper;
import com.infinite.daointerface.IProduct;
import com.infinite.pojo.Product;


public class ProductImpl implements IProduct {
	static Session sessionObj;
	static SessionFactory sessionFactoryObj;
	private Configuration con;
	private Transaction t;

		public void saveData(Product e) {
			con = new Configuration().configure("hibernate.cfg.xml");
			sessionFactoryObj = con.buildSessionFactory();
			sessionObj = sessionFactoryObj.openSession();
			t = sessionObj.beginTransaction();
			sessionObj.save(e);
			t.commit();
		}
		
	public void create(String Productname, float price, int qunatity, float total, Product pr) {
			// TODO Auto-generated method stub
			// Getting Session Object From SessionFactory

						try {
							sessionObj = DaoHelper.buildSessionFactory().openSession();
							// Getting Transaction Object From Session Object
							sessionObj.beginTransaction();
							Product p = (Product) sessionObj.get(Product.class,pr.getProductid());
							p.setName(p.getName());
							p.setPrice(p.getPrice());
							p.setQuantity(p.getQuantity());
							p.setTotal(p.getTotal());
							sessionObj.update(p);
							sessionObj.save(p);
							sessionObj.getTransaction().commit();
						} catch (Exception ex) {
							ex.printStackTrace();
						} finally {
							try {
								sessionObj.close();
							} catch (Exception e11) {
								e11.printStackTrace();
							}

						}
		}
		
	

	public void update() {
		// TODO Auto-generated method stub
		
	}

	public void delete() {
		// TODO Auto-generated method stub
		
	}
	
	
		
		
	}
	

