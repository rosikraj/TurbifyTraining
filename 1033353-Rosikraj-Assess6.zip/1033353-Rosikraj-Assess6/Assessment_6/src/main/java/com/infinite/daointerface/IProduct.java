package com.infinite.daointerface;

import com.infinite.pojo.Product;

public interface IProduct {
	public void create(String Productname, float price, int qunatity, float total,Product pr );
	public void update();
	public void delete();
	
}
