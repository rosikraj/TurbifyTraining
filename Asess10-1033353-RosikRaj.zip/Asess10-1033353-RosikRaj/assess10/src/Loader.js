import Stack from 'react-bootstrap/Stack';
import './Loader.css';

function Loader() {
  return (
    <Stack gap={3}>
      <div className="box1">LOADING</div>
      <div className="box2">SCREEN</div>
      <div className="box3">REACTJS</div>
    </Stack>
  );
}

 

 
export default Loader;
