import './App.css';
import Loader from './Loader';
import LoadingSpin from './Loading';
import Population from './Population';
import Pharmacy from './Registration';

function App() {
  return (
    // <div className="App">
    //   <header className="App-header">
    //     <h1 background color='blue'><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOUAAAB4CAMAAAA678W5AAAAjVBMVEUiIiJh2vtj3/9i3f8cAAAhHx5k4/9k4f8ZAAAfEw4hHRwgGRYgGhhl5f8hHBodCgBZxeBEjKA0X2xWvdk/fpAlLTFd0e4mMTUgFhRby+keDgkdBQAjJigkKS0tSlRGkaRNpr4nNT02ZnUxVmI7coIpOj9TtcsrQklRr8lJmawfGBoRAABn6v9BhJNMorW5ZYAyAAAHnklEQVR4nO2aDZOiOBPHyRsJIhAMhjcFBlBwZ/T7f7yno+soc7d3dbVbNeap/Gp2lwHWSttJ97878TyHw+FwOBwOh8PhcDgcDofD4XA4HI7vgAH//ZFdrOrd4ZAHyV+tYUmQHw67evUNo/rDBPvsKKXqsh1d2snoLuuUlMdsH3zT2P4YwSQxNyDdroKHnSxYtRpdn2A5WW7meo8wRlKWhBMfjSz8eT9kI/LhXiklIhjt1986yt+l6jguN4e86TvOCVbb+nq73ipMOO/6Jj9sSsy76pvH+VsUgya6SWK2DopmxoToTQK3k40mBM9NEaxZnDTwzlB891B/g6DlpL25zwvFWGKCU8poCv+Wo/g5feuW8NbqlTlzvfk0IJmUD2YKMNJXU3K/HWw0n79neH8Elpek3D0Cayg6TkhJCO/ujjRv7eCt3F5xwN40luL5RtUiQ1s9GyUk1m8WW3kgZGGltxIzQWQWC7kjJCEHm63ERC2srFIwEpF0kTmEIthmK9/QcsbSETQApEo80qe7MGORzTP2rcTyyW3VBAqoE51P0PR8W+LSZitB4uhDfP81PJSgBcRKgDfLw2eQjQ8aRJG9Vl7z5UPWFKB+ZB57cS7B2sftwe586RUnjkaYmywOi0KkPtINLYqCNhr5qSiKMAYXViPiJ6sVXgbiTdBkNw39eMYIlVBrQh1yLBHC57Efpl1CBcjAzGaFB+INHzdpd5SacB/kAME3CFxDkaLlsUs3R/wkA22DBcVuo41pBAppYxc4U9+4XiMovqBOgQu92RWBjfGHUda3JeQMRHxSqlnB1dhM+daQT80ID+CuJrdXyrZn1Do7kypTCDzlIyLHTZNTRaKTCNfxyhCvQ3GKiKJ5sxklQVCqcKSyKvn3D34hCm/UHNagVhksvvcwpi3G8sezr9gPiXFL4/AdlmymNKxVrkfPolhLh9l4R6UNfZfkoynWjSaov0UYtr4ZG/SI6GZdNB9EvtMmVcbz80D/6YNfCQHjJ5HabJPQq88RP1F68UEGGOsCEeTwB64YiAT/QumJR+faC5PtRkUQinrxbx//GgSpT3i5EdegySYEJfL0gdA2NH4cy4+Pj3I0/lxvEfqYoNBG0/XNQGxK0LmpFUklMXXHnP/s9nisA/lzxH5rpiLtuMkgmHfX31ofH0H4dPf1WuegAdFoQQxiAvJCV3xqcdBvpIQfI8dp6qMbfkqNmAc/ws/4WZ+EhalXxOtnFHqOsHp/aqLvIFMgnIEl1xh0w8Qd+AYy8CyRT50h9q5wdH79CEQV5ovuqnEglCIrWLAjRnfwCMtvlZtcmT4bVQwcq5e3krGvJTGjPrjSDLw6+59W+mczTSk4019IHii8iXz93b5AkmVDrpgiRC4mGAXZk5XXKqS+EBRNz55nb5rI14+yArLgsqsDQRaWYXHVAQ+MRijMQuXdsjPE8fz6KTMYIoSediRDqJjBlEthApH6jD7KhJziAl8AVNaPDnSwRygaXt+XngCpJpt7uvSqlJNZE2xMqQZ0iz8YDZX5AjDRM+GPvmXdSBCGr+9Kz4snUN66/7lFwPYKTDr5/DoNaa9BxZFI92ZOi5n7JzBc7W/rOBS9+a9T/OsPfx2CSYJQm5vQSLxw8Imqa5BDvZE0lZcpqTLPeC/pQejUtSL+YMRfEDag8bk1G9NVfoThoktf0BU9+X5GAyjAlEmZHquFELXx3SpXUHIFNPP9E7xX9BcEX84xt2bDNvQyYuyU2f4dFDmL2RbW23mpT5MzrN8tWzFQ8u/7TBobSebZtPdOaVsSqBcjiDuyDhIxgLpdJMZiAsU6iCSoJcSgCOpRUrb05VXPEkYPZ8V907vSx0vaTzMB5UZpnRhquFIYd1OfXo7a9L98rs4H+xo/XlztG3CoqbOg3DJtOzK3aTYasrSdrw2920MoWdpmX1kRW/8CiwWoUq008n1uWrCE+74fRRH8bTqXBMPvCJ6T8k3E9vnxTgA18oUN/fk0S32101gIXG3Ucj6d+4GBAhotSR9/SwDCJ6VhkKy93X4LolXCZE1h2kqQttv9zlsnQUhTkD82W7kCN91bdyyBOIsyAYFHZHA1JOyzmccvFp84ZLsjf9LiVYqNcUbOEvwQr6Dn+XFn77K8noTZf46fJeYgTE5zcxTmcZL0/+IkzFOiX9WKEzlIwtXzoVhq+0kYtDwJU0C9YgovvZBBQhJk8xmRA/lyEiZoSrCybBYhVSi7z/u8ffGlV2wVQURtF5s+xpc2z9gv69ILduA2iEBq9+xM29elOQnzKP0ZpBBOyrQkHDePk3jWn4RZdfyxPxDSMyhZPYhBg4o903seNWdEOotVgdki4Jfb5IyT7cyh2Gwqr2qgpMTzNrl5Objw6waDtcQTzM6MJgmtmhbDguwKY3NQdLA8cdtU5lEGs9iOjtavoGmESJeNWVf6MFuz5DYzV0kGs9Yvr08IilLLegRfEWbv/XoYBvNu/5iXwb7j+HoMxuyz29CB/Ud+tKUpKLG8NIt9SSaaiyTmUdn++LbR/SlY1YwtFMsT/Xr8o6ATlNft2FQWZ5FP4iIIguLvwsuvnzgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcjgX/A9vNhG6zzGRKAAAAAElFTkSuQmCC" className="App-logo" alt="logo" width="450px" height="100px"/>React </h1>
    //     {/* <Loader/> */}
    //     <div className='loader'>
    //     {/* <LoadingSpin/> */}
    //     {/* <Population/> */}
    //     <Pharmacy/>
        
    //   </div>
    //   </header>
    // </div>
    // <div>
    //   {/* <Pharmacy/> */}
    //   <Population/>
    // </div>
    <div>
      <Population/>
    </div>
  );
}
 
export default App;
 