import React from 'react';
import axios from 'axios';
 
export  class Population extends React.Component {
 
    state = {
        persons: []
    }
 
 
 
    componentDidMount() {
        axios.get('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
            .then(res => {
                const persons = res.data;
                console.log(this.state.persons)
                this.setState({ persons: persons.data });
            })
    }
 
    render() {
      return (
        <div>
        <table border="1" align='center' cellPadding={15}  >
              <thead>
                  <tr>
                    
                      <th>ID Nation</th>
                      <th> Population</th>
                      <th> Year </th>
                  </tr>
 
              </thead>
              <tbody>
                  {
                        this.state.persons
                        .map(person =>
                          <tr key={person.IDNation}>
                            <td>01000US</td>
                             
                          <td>{person.Population}</td>
                          
                          <td>{person.Year}</td>
                          
                         </tr>
                      )
                      }
              </tbody>
          </table>
          </div>
 
      )
  }
}
export default Population;